#include <stdio.h>

int main(void)
{
    int tamarchivo;
    int primerpix;
   
        scanf_s("%i", &tamarchivo);
        scanf_s("%i", &primerpix);

    printf("BM%08X00000000%08X", tamarchivo, primerpix);

    return 0;
}
