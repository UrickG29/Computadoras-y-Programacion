#include <stdio.h>
#include <math.h>
int main()
{
    double xlimiteinicial;
    double limitefinal;
    double incremento;
    double resultadodelexponente;
    double valoresx;
    int numfactorial;
    int valauxi;
    int iconta;
    int betra;
    int r;

    scanf_s("%lf", &xlimiteinicial);
    scanf_s("%lf", &limitefinal);
    scanf_s("%lf", &incremento);

    valoresx = xlimiteinicial;
    numfactorial = (limitefinal - xlimiteinicial) / incremento;

    if (xlimiteinicial == 0 && limitefinal == 0 && incremento == 0)
    {
        printf("0.000000 1.000000 1.000000");
    }


    if (xlimiteinicial <= limitefinal)
    {
        for (iconta = 0; iconta <= numfactorial; iconta++)
        {
            resultadodelexponente = 0;

            for (betra = numfactorial; betra != -1; betra--)
            {
                valauxi = 1;

                for (r = betra; r != 0; r--)
                {
                    valauxi *= r;
                }
                valauxi += (valauxi == 0) ? 1 : 0;
                resultadodelexponente += (pow(valoresx, betra)) / valauxi;
            }
            printf("%f %f %f\n", valoresx, resultadodelexponente, exp(valoresx));
            valoresx += incremento;
        }
    }
    return 0;
}



