#include <stdio.h>

int main()

{
    int idia, imes, ian;

    scanf_s("%i", &idia);
    scanf_s("%i", &imes);
    scanf_s("%i", &ian);


    if (idia >= 1 && idia <= 28 && imes == 2 && (ian % 4 == 0))
    {
        idia++;
    }
    else
        if (idia >= 1 && idia <= 29 && imes == 2 && (ian % 4 == 0))
        {
            idia = 1;
            imes = 3;
        }
        else
            if (idia == 28 && imes == 2 && (ian % 4 != 0))
            {
                idia = 1;
                imes = 3;
            }
            else
                if (idia >= 1 && idia <= 31)
                {
                    idia++;
                }
    if (idia > 31)
    {
        idia = 1;
        imes++;
    }
    if (imes > 12)
    {
        imes = 1;
        ian++;
    }


    printf("%2i %2i %4i", idia, imes, ian);
    return 0;
}