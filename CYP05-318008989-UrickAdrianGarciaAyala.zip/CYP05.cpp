#include <stdio.h>

int main() {
	int cuenta = 0;
	float calif = 0;

	int i = 0 , k, n = 0, numLista = 0;

	//ingresar calificaciones para n alumnos
	scanf_s("%d", &n);
	//se generan los arreglos con tama�o n
	int listaCuenta[2000] = { 0 };
	float listaCalificaciones[2000] = { 0 };

	int j = 1;
	while (j <= n) {
		scanf_s("%d %f", &cuenta, &calif);

		int flag=0;
		for (k = 0; k < n; k++) {
			if (listaCuenta[k] == cuenta) {
				//la bandera cambia a 1
				flag = 1; //si esta
				break;
			}
			else {
				flag = 0;
			}
		}
		//printf("bandera=%d\n",flag);
		//si esta en lista se valida calif		
		if (flag == 1) {

			for (k = 0; k < n; k++) {
				if (listaCuenta[k] == cuenta)
					numLista = k; //si esta	
			}
			//comparacion: si la nueva calificacion es mas alta que la anterior
			if (calif > listaCalificaciones[numLista]) {
				listaCalificaciones[numLista] = calif;
			}

		}
		else {//si no esta en lista se agrega
			listaCuenta[i] = cuenta;
			listaCalificaciones[i] = calif;
			i++;
		}
		j++;
	}

	//numero de cuentas sin repetir
	if (i == 1) 
	{
		printf("1\n");
	}
	else
	{
		printf("%d\n", i);
	}
	

	//ordenar
	int temp , l = 0, m , p ;
	float temp2;

	for (l = 0; l < n; l++) {
		for (m = 0; m < n - 1; m++) {
			if (listaCuenta[m] > listaCuenta[m + 1]) {
				p = m;
				//orden de lista de cuenta
				temp = listaCuenta[m];
				listaCuenta[m] = listaCuenta[m + 1];
				listaCuenta[m + 1] = temp;
				//orden de lista de calificaciones
				temp2 = listaCalificaciones[p];
				listaCalificaciones[p] = listaCalificaciones[p + 1];
				listaCalificaciones[p + 1] = temp2;
			}
		}
	}

	//imprimir
	for (l = 0; l < n; l++) {
		if (listaCuenta[l] != 0)
			printf("%d %f\n", listaCuenta[l], listaCalificaciones[l]);
	}

	return 0;
}