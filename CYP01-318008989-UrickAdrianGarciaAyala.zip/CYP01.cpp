#include <stdio.h>

int main()
{
    int ianchop, ialtop, ixsupizq, iysupizq, ixinfder, iyinfder; 
    float fcoordx, fcoordy, fporcentajeancho, fporcentajealto;

        scanf_s("%i", &ianchop);
        scanf_s("%i", &ialtop);
        scanf_s("%f", &fcoordx);
        scanf_s("%f", &fcoordy);
        scanf_s("%f", &fporcentajeancho);
        scanf_s("%f", &fporcentajealto);

        ixsupizq = (int) (ianchop * fcoordx);
        iysupizq = (int) (ialtop * fcoordy);
        ixinfder = (int) (ianchop * fporcentajeancho + ixsupizq);
        iyinfder = (int) (ialtop * fporcentajealto + iysupizq);
  
                printf("%i %i %5.2f %5.2f %5.2f %5.2f %i %i %i %i", ianchop, ialtop, fcoordx, fcoordy, fporcentajeancho, fporcentajealto, ixsupizq, iysupizq, ixinfder, iyinfder);

                    return 0;
}